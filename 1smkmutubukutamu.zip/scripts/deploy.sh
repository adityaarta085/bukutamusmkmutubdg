#!/bin/bash

echo "🚀 Starting deployment process..."

# Build the application
echo "📦 Building application..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Build failed!"
    exit 1
fi

echo "✅ Build successful!"

# Create netlify directory structure
echo "📁 Creating Netlify directory structure..."
mkdir -p .netlify/functions

# Copy standalone build
echo "📋 Copying build files..."
cp -r .next/standalone/* ./
cp -r .next/static ./

# Create _headers file for better routing
echo "📝 Creating _headers file..."
cat > public/_headers << EOF
/*    X-Frame-Options: DENY
/*    X-Content-Type-Options: nosniff
/*    Referrer-Policy: strict-origin-when-cross-origin
/*    Permissions-Policy: camera=(), microphone=(), geolocation=()
EOF

echo "✅ Deployment files ready!"
echo "🌐 Ready for Netlify deployment!"
echo "📝 Next steps:"
echo "   1. Run 'npm run build' to create production build"
echo "   2. Deploy the 'out' directory to Netlify"
echo "   3. Make sure to set build command to 'npm run build'"
echo "   4. Set publish directory to 'out' or '.'"
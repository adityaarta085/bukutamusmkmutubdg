# 🏫 **SMK Muhammadiyah Bandongan - Buku Tamu Digital**

Aplikasi buku tamu digital modern dengan fitur lengkap untuk SMK Muhammadiyah Bandongan.

## ✨ **FITUR LENGKAP:**

### 📝 **Buku Tamu Digital**
- ✅ Form pendaftaran tamu yang user-friendly
- ✅ Dokumentasi foto dengan kamera atau upload
- ✅ Tanda tangan digital (responsive untuk mobile & desktop)
- ✅ Auto timestamp atau manual input
- ✅ Data instansi, tujuan, dan pesan

### 👨‍💼 **Admin Dashboard**
- ✅ Management data tamu (CRUD)
- ✅ Admin management (maksimal 2 admin)
- ✅ Event & acara management
- ✅ Real-time statistics
- ✅ Export data ke CSV
- ✅ Search dan filter data

### 📱 **Mobile Responsive**
- ✅ Camera popup yang optimal untuk mobile
- ✅ Touch-friendly signature canvas
- ✅ Responsive design untuk semua device
- ✅ Optimized untuk tanda tangan jangka pendek (7 hari)

### 🚀 **Production Ready**
- ✅ Auto-deployment dengan Vercel
- ✅ PostgreSQL database (Vercel Postgres)
- ✅ Cloud file storage (Vercel Blob)
- ✅ SSL certificate
- ✅ Custom domain support

## 🎯 **QUICK DEPLOY (5 MENIT):**

### **1. Push ke GitHub**
```bash
git add .
git commit -m "Ready for deployment"
git push origin main
```

### **2. Deploy ke Vercel**
1. Buka `https://vercel.com`
2. Login dengan GitHub
3. Click **"New Project"**
4. Pilih repository → **"Deploy"**

### **3. Setup Database & Storage**
1. Di Vercel Dashboard → **"Storage"**
2. Create **"Postgres"** database
3. Create **"Blob"** storage
4. Run: `npm run db:push`

### **4. SELESAI!** 🎉
- **App**: `https://your-app.vercel.app`
- **Admin**: `https://your-app.vercel.app/admin/dashboard`
- **Login**: `admin` / `admin123`

---

## 🛠️ **TECHNOLOGY STACK:**

- **Framework**: Next.js 15 with App Router
- **Language**: TypeScript 5
- **Database**: PostgreSQL (Vercel Postgres)
- **Storage**: Vercel Blob Storage
- **Styling**: Tailwind CSS 4
- **UI Components**: shadcn/ui
- **Authentication**: JWT with bcryptjs
- **Deployment**: Vercel

## 📁 **PROJECT STRUCTURE:**

```
src/
├── app/
│   ├── page.tsx                 # Halaman utama (buku tamu)
│   ├── admin/
│   │   └── dashboard/
│   │       └── page.tsx        # Admin dashboard
│   └── api/                   # API routes
├── components/
│   └── ui/                    # UI components
├── lib/
│   ├── db.ts                  # Database connection
│   └── vercel-blob.ts         # File storage
└── prisma/
    └── schema.prisma          # Database schema
```

## 🔧 **LOCAL DEVELOPMENT:**

### **Install Dependencies**
```bash
npm install
```

### **Setup Database**
```bash
npm run db:push
npm run reset-admin  # Reset admin credentials
```

### **Start Development Server**
```bash
npm run dev
```

### **Build for Production**
```bash
npm run build:vercel
```

## 📚 **GUIDES & DOCUMENTATION:**

- **[QUICK-START.md](./QUICK-START.md)** - Deploy dalam 5 menit
- **[VERCEL-DEPLOYMENT.md](./VERCEL-DEPLOYMENT.md)** - Deployment guide lengkap
- **[DEPLOYMENT.md](./DEPLOYMENT.md)** - Alternative deployment options

## 🔐 **DEFAULT CREDENTIALS:**

- **Username**: `admin`
- **Password**: `admin123`

## 🎨 **FEATURES HIGHLIGHT:**

### **Tanda Tangan Digital**
- Responsive untuk mobile & desktop
- Kualitas optimal untuk 7 hari penyimpanan
- Touch-friendly interface
- Simple controls (hapus & simpan)

### **Kamera Integration**
- Popup modal yang modern
- Support switch camera (depan/belakang)
- Optimized untuk mobile
- Fallback ke file upload

### **Admin Dashboard**
- Tab-based navigation
- Real-time statistics
- Data visualization
- Export functionality
- Search & filter

## 🌟 **WHY THIS APP?**

1. **Modern Stack** - Next.js 15, TypeScript, Tailwind CSS
2. **Production Ready** - Auto-deployment, database, storage
3. **Mobile First** - Responsive design, touch-friendly
4. **Easy Deploy** - Tinggal push ke GitHub, deploy ke Vercel
5. **Complete Features** - Semua yang dibutuhkan buku tamu digital
6. **Maintainable** - Clean code, good structure, TypeScript

## 🤝 **CONTRIBUTION:**

1. Fork repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## 📞 **SUPPORT:**

Jika butuh bantuan:
- Cek documentation di folder ini
- Test di local development dulu
- Pastikan semua environment variables ter-set
- Contact developer untuk setup bantuan

---

## 🎉 **SELAMAT MENGGUNAKAN!**

**SMK Muhammadiyah Bandongan - Success By Discipline**

*Built with ❤️ using Next.js 15, TypeScript, and Vercel*
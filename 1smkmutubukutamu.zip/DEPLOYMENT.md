# 🚀 Netlify Deployment Guide

## ⚠️ **VERY IMPORTANT - READ FIRST!**

Aplikasi ini **TIDAK AKAN BEKERJA** di Netlify tanpa setup tambahan karena:

1. **SQLite tidak bekerja** di Netlify (static hosting)
2. **File upload ke filesystem** tidak bekerja di Netlify

## 📋 **PREREQUISITES (WAJIB DIPERSIAPKAN)**

### 1. **Database External (PILIH SALAH SATU)**

#### Option A: Supabase (Recommended)
```bash
# Buat account di https://supabase.com
# Buat project baru
# Dapatkan credentials:
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

#### Option B: PlanetScale
```bash
# Buat account di https://planetscale.com
# Buat database baru
# Dapatkan connection string:
DATABASE_URL=mysql://user:password@host:port/database
```

### 2. **File Storage (PILIH SALAH SATU)**

#### Option A: Cloudinary (Recommended)
```bash
# Buat account di https://cloudinary.com
# Dapatkan credentials:
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

#### Option B: Vercel Blob
```bash
# Install: npm install @vercel/blob
# Setup Vercel Blob storage
```

## 🔧 **STEP-BY-STEP DEPLOYMENT**

### Step 1: Prepare Environment Variables

Buat file `.env.production`:
```bash
# Database (pilih salah satu)
DATABASE_URL=your_external_database_url
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_key

# File Storage (pilih salah satu)
CLOUDINARY_CLOUD_NAME=your_cloudinary_cloud_name
CLOUDINARY_API_KEY=your_cloudinary_api_key
CLOUDINARY_API_SECRET=your_cloudinary_api_secret

# Authentication
JWT_SECRET=your_super_secret_jwt_key_min_32_chars
NEXTAUTH_URL=https://your-site.netlify.app
NEXTAUTH_SECRET=your_nextauth_secret

# Environment
NODE_ENV=production
```

### Step 2: Update Prisma Schema

Jika menggunakan Supabase/PostgreSQL:
```prisma
// prisma/schema.prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

Jika menggunakan PlanetScale/MySQL:
```prisma
// prisma/schema.prisma
datasource db {
  provider = "mysql"
  url      = env("DATABASE_URL")
}
```

### Step 3: Push Schema to Production

```bash
# Generate Prisma client
npm run db:generate

# Push schema to production database
npm run db:push
```

### Step 4: Deploy to Netlify

#### Option A: Via Netlify CLI (Recommended)
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login ke Netlify
netlify login

# Deploy
netlify deploy --prod
```

#### Option B: Via Git (GitHub/GitLab)
1. Push code ke repository
2. Connect repository ke Netlify
3. Set environment variables di Netlify dashboard
4. Deploy

### Step 5: Set Environment Variables di Netlify

Di Netlify Dashboard → Site Settings → Environment Variables:

```bash
DATABASE_URL=your_external_database_url
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_key
CLOUDINARY_CLOUD_NAME=your_cloudinary_cloud_name
CLOUDINARY_API_KEY=your_cloudinary_api_key
CLOUDINARY_API_SECRET=your_cloudinary_api_secret
JWT_SECRET=your_super_secret_jwt_key_min_32_chars
NEXTAUTH_URL=https://your-site.netlify.app
NEXTAUTH_SECRET=your_nextauth_secret
NODE_ENV=production
```

### Step 6: Build Settings di Netlify

Di Netlify Dashboard → Site Settings → Build & deploy:

```bash
# Build command
npm run build:netlify

# Publish directory
.next

# Node version
18

# NPM version
9
```

## 🔍 **POST-DEPLOYMENT CHECKLIST**

### 1. **Test Database Connection**
- Buka `/admin/dashboard`
- Coba login dengan default credentials
- Jika error, cek database connection

### 2. **Test File Upload**
- Buka halaman utama
- Coba upload foto dan tanda tangan
- Cek apakah muncul di database

### 3. **Test All Features**
- Guest form submission
- Admin dashboard
- Event management
- Export CSV

## 🚨 **TROUBLESHOOTING**

### Error: "Database connection failed"
```bash
# Solution: Cek environment variables
# Pastikan DATABASE_URL benar
# Pastikan database accessible dari Netlify
```

### Error: "File upload failed"
```bash
# Solution: Cek Cloudinary credentials
# Pastikan CLOUDINARY_CLOUD_NAME benar
# Pastikan API key dan secret benar
```

### Error: "JWT secret not found"
```bash
# Solution: Set JWT_SECRET di environment variables
# Minimal 32 karakter
```

## 📝 **ALTERNATIVE DEPLOYMENT OPTIONS**

Jika Netlify terlalu complicated, coba:

### Option 1: Vercel (Recommended)
```bash
# Vercel support Next.js better
# Auto-detects Next.js apps
# Built-in database options
```

### Option 2: Railway
```bash
# Support SQLite
# Easy deployment
# Built-in database
```

### Option 3: DigitalOcean App Platform
```bash
# Support Next.js
# Built-in database
# Easy scaling
```

## 💡 **RECOMMENDATION**

Untuk production yang stabil, saya sarankan:
1. **Gunakan Vercel** (lebih mudah untuk Next.js)
2. **Gunakan Supabase** untuk database
3. **Gunakan Cloudinary** untuk file storage

## 🆘 **HELP NEEDED?**

Jika butuh bantuan:
1. Cek error logs di Netlify
2. Verify semua environment variables
3. Test database connection
4. Contact developer untuk setup bantuan

---

## ⚡ **QUICK DEPLOY (If You Have External Database)**

Jika Anda sudah punya external database dan Cloudinary:

1. Set environment variables
2. Run: `npm run build:netlify`
3. Deploy ke Netlify
4. Test semua features

**Selamat! 🎉**